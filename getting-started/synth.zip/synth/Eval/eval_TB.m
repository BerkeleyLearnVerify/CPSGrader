function eval_TB( Sys, tb_name )
%EVLA Summary of this function goes here
%   Detailed explanation goes here

eval(['load Data/Eval/' tb_name '_neg']);
eval(['load Data/Eval/' tb_name '_pos']);

neg_correct = 0;
neg_total = 0;

pos_correct = 0;
pos_total = 0;

for i = 1:numel(neg_list)
    neg = neg_list(i);
    traj = traj_neg(i);
    if ( ~any(traj.X(1,:)) )
        
    else
        eval(['pass = test_' tb_name '_ats(Sys, traj);']);
        if ( pass == 0 )
            neg_correct = neg_correct + 1;
        end
        neg_total = neg_total + 1;
    end
end

for i = 1:numel(pos_list)
    traj = traj_pos(i);
    
    if ( ~any(traj.X(1,:)) )
        
    else
        eval(['pass = test_' tb_name '_ats(Sys, traj);']);
        if ( pass == 1 )
            pos_correct = pos_correct + 1;
        end
        pos_total = pos_total + 1;
    end
end


save(['Data/Eval/' tb_name '_eval'], 'neg_correct', 'neg_total', 'pos_correct', 'pos_total');
end