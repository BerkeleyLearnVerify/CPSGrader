Synthesis and Evaluation scripts for the CIRCLE fault

Requirements: Recent version of MATLAB and a compatible C/C++ compiler.

To run these, please install Breach
(http://www.eecs.berkeley.edu/~donze/breach_download_and_install.html) and make
sure that all of Breach folders and sub-folders are on MATLAB path


Say you unzip the sources in a location $ROOT. $ROOT should have Data, Eval,
Synthesis, properties, TB as its subdirectories. Make sure $ROOT is on MATLAB
path with all its sub-folders.

1. Data: Contains training and evaluation trajectories
2. Eval: Contains test bench evaluation scripts
3. properties: Contains PSTL formulae
4. Synthesis: Source code for synthesis of test benches
5. TB: Test Benches

In MATLAB command line, make sure the the current directory is $ROOT. Now srun
the following commands.

>>> init_tests_ats      % this initializes all tests and sets up Breach for use
                        % with the grader

>>> mk_TB_circle(Sys)   % this synthesizes the test bench for circle property
                        % using trajectories from Data/Training/circle_pos.mat
                        % and circle_neg.mat
                        % this will write the file Data/Training/circle_tb.mat
                        % which contains the parameter names {names}, domains
                        % {domains}, test bench constrains {rho}, the adequate
                        % test sample {ats}.

>>> eval_TB(Sys, 'circle') % this uses trajectories from Data/Eval/circle_neg.mat
                           % and circle_pos.mat for evaluation. It write a file
                           % Data/Eval/circle_eval.mat which contains the
                           % accuracy results. 
                           % 

>>> plot_TB('circle')  % this plots the test bench constrains rho for the circle
                       % circle property. You will have to rotate appropriate to
                       % see tau and delta on the x and y axes.

