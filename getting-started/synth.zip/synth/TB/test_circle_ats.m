function [pass] = test_circle_ats(Sys, traj)
%
% This tests uses environment 2: robot faces obstacle toward right
%
% Success: circles
%

load Data/test_formulas_ats

P = CreateParamSet(Sys);
%P = SetParam(P, 'file_no', file_no);

% Specify test environment 
%P = SetParam(P, 'env_no', 2);
P = SetParam(P, {'tref' 'small_angle'}, [0 5]);

load Data/Training/circle_tb

pass = 0;
for i = 1:size(ats, 2)
    p_val = ats(:, i);
    P_new = SetParam(P, {'tau', 'delta'}, p_val');
    %P_new = ComputeTraj(Sys, P_new, Sys.tspan);
    val = QMITL_Eval(Sys, phi_circle_old, P_new, traj,0);
    if( val > 0 )
        pass = 1;
        break;
    end
end