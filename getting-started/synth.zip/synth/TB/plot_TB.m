function plot_TB( tb_name )
%PLOT_TB Summary of this function goes here
%   Detailed explanation goes here

load(['Data/Training/' tb_name '_tb']);

if ( numel(domains) == 2)
    figure
    surf(domains{2}, domains{1}, rho+2*ones(size(rho)), 'EdgeColor', 'none');
%    contourf(domains{2}, domains{1}, rho);
    xlabel(names{2});
    ylabel(names{1});
    map = [1 0 0; 1 1 1; 0 1 0];
    colormap(map);
    %scatter(ats(2,:), ats(1,:));
else
    
end

end

