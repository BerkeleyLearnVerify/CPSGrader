Sys = init_monitor_ats;

formulas = QMITL_ReadFile('properties/error_models.stl');
for iphi= 1:numel(formulas)
   eval([formulas{iphi} '=QMITL_OptimizePredicates(Sys,' formulas{iphi} ');']); 
end

save('Data/test_formulas_ats', formulas{:})
Tests = {
    @(file_no) (test_circle_ats(Sys, file_no)) ....
};