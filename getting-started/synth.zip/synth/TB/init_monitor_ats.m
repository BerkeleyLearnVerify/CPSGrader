function Sys = init_monitor_ats()

name = ['irobot_env'];
signals = {'x', 'y', 'z', 'pitch', 'roll', ...
    'yaw', 'dist', 'angle', 'ax', 'ay', 'az', ...
    'bump_l', 'bump_r', 'drop_l', 'drop_r', ...
    'drop_f', 'cliff_l', 'cliff_fl', 'cliff_fr', ...
    'cliff_r', 'lws', 'rws', 'state'};

params = {'env_no', 'file_no'};
p0 = [1 1];

Sys = CreateExternSystem(name, signals, params, p0, @sim_monitor);

% Get lists of traces 
% 
% for ii = 1:16
%     
%     list_of_traces_env{ii} = ['traces\env' int2str(ii) '.txt'];
%     if (strcmp(mexext,'mexmaci64'))
%         list_of_traces_env{ii} = dos2unix(list_of_traces_env{ii});
%     end
%     
%     Sys.traces_env{ii} = {};
%     fid = fopen(list_of_traces_env{ii}, 'r');
%     Sys.nb_traces_env(ii)=0;
%     tline = fgetl(fid);
%     
%     while ischar(tline)
%         if (strcmp(mexext,'mexmaci64'))
%             tline = dos2unix(tline);
%         end
%         
%         Sys.nb_traces_env(ii)= Sys.nb_traces_env(ii)+1;
%         Sys.traces_env{ii} = { Sys.traces_env{ii}{:},  tline };
%         tline = fgetl(fid);
%     end
%     fclose(fid);
% end

Sys.tspan = 0:.005:100; % default tspan


function fid = dos2unix(fid)
fid = regexprep(fid,'\','/');
