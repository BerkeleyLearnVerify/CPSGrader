
function [ats, rho, domains] = mk_TB_circle(Sys)

load Data/test_formulas_ats
load Data/Training/circle_neg
load Data/Training/circle_pos

names = {'tau' 'delta'};
domains = {1:0.5:10 ...
    -0.025:0.01:0.2};% ...
%    -1:5:100};
P = CreateParamSet(Sys);
% P = SetParam(P, 'small_angle', 5);
 P = SetParam(P, {'tref' 'small_angle'}, [0 5]);

[ats, rho] = mk_TB(Sys, P, phi_circle_old, names, domains, 2,...
    traj_pos(1:5), traj_neg(1:25));

 save Data/Training/circle_tb names domains ats rho