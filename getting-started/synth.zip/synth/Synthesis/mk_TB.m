function [ p_corners, p_rho, num_sims ] = mk_TB( Sys, Pinit, phi,...
    p_names, p_domains, k_mono, traj_pos, traj_neg )
%SYNTH_SUB_DOMAIN Synthesis sub domain from positive and negative egs
%   - phi property
%   - p_names list of parameter names
%   - p_domain list of parameter domains (cartesian product projections)
%   - k_mono last k_mono parameters are monotonic (increasing)
%   - traj_pos trajectories for which phi should be true
%   - traj_neg trajectories for which phi should be false
%

p_num_dims = numel(p_domains);

% get size of each dimension
p_dim_sizes = zeros(1, p_num_dims);
for p_dim_no = 1:p_num_dims
    p_dim_sizes(p_dim_no) = numel(p_domains{p_dim_no});
end

% create the cell array of index for each dimension
p_domains_indices = cell(1, p_num_dims);
for p_dim_no = 1:p_num_dims
    p_domains_indices{p_dim_no} = 1:p_dim_sizes(p_dim_no);
end

% initialize rho to a p dimensional array
p_rho = zeros(p_dim_sizes);

    function val = get_elem( p_index )
        p_index_cell = num2cell(p_index);
        val = p_rho(p_index_cell{:});
    end

    function set_elem( p_index, val )
        if ( get_elem(p_index) == 0 )
            p_index_cell = num2cell(p_index);
            p_rho(p_index_cell{:}) = val;
        end
    end

    function test_res = run_test(  traj, p_index )
        num_sims = num_sims+1;
        P = Pinit;
        if ( numel(p_index) ~= p_num_dims)
            disp('index not compatilble with dims');
        end
        for p_dim_no_l = 1:p_num_dims
            P = SetParam(P, p_names{p_dim_no_l},...
                p_domains{p_dim_no_l}(p_index(p_dim_no_l)));
        end
        
%         P = ComputeTraj(Sys, P, Sys.tspan);
%         P.traj = traj;
%         P.traj_ref (:) = 1;
%         P.traj_to_compute = [];
        val = QMITL_Eval(Sys, phi, P, traj, 0);
        test_res = val > 0;
    end

    function fill_rho( p_domains_indices, p_index, traj, is_pos )
        if ( numel(p_domains_indices) > 2 )
            cur_p_domain = p_domains_indices{1};
            p_domains_rest = {p_domains_indices{2:end}};
            for cur_p_val = cur_p_domain
                p_index_new = [p_index cur_p_val];
                fill_rho(p_domains_rest, p_index_new, traj, is_pos);
            end
        elseif ( numel(p_domains_indices) == 2)
            if ( k_mono >= 2 )
                p_domain_U = p_domains_indices{1};
                p_domain_V = p_domains_indices{2};
                p_sz_U = numel(p_domain_U);
                p_sz_V = numel(p_domain_V);
                
                idx = [ 1 p_sz_V];
                while ( idx(1) <= p_sz_U && idx(2) >= 1 )
                    p_index_new = [p_index idx];
                    test_res = run_test(traj, p_index_new);
                    if ( test_res > 0 )
                        for U_to_set = idx(1):p_sz_U
                            p_index_to_set = [p_index U_to_set idx(2)];
                            if is_pos
                                set_elem(p_index_to_set, 1);
                            else
                                set_elem(p_index_to_set, -1);
                            end
                        end
                        idx = [ idx(1) idx(2)-1];
                    else
                        idx = [ idx(1)+1 idx(2)];
                    end
                end
            else
                cur_p_domain = p_domains_indices{1};
                p_domains_rest = {p_domains_indices{2:end}};
                for cur_p_val = cur_p_domain
                    p_index_new = [p_index cur_p_val];
                    fill_rho(p_domains_rest, p_index_new, traj, is_pos);
                end
            end
        elseif ( numel(p_domains_indices) == 1 )
            if ( k_mono == 1 )
                p_sz_U = numel(p_domains_indices{1});
                l = 1; h = p_sz_U
                while ( h >= l )
                    m = floor((h + l)/2);
                    p_index_new = [ p_index m ];
                    test_run = run_test(traj, p_index_new);
                    if ( test_run > 0 )
                        for i_to_set = m:h
                            p_index_to_set = [p_index i_to_set];
                            if is_pos
                                set_elem(p_index_to_set, 1);
                            else
                                set_elem(p_index_to_set, -1);
                            end
                        end
                        h = m-1;
                    else
                        l = m+1;
                    end
                end
            else
                cur_p_domain = p_domains_indices{1};
                p_domains_rest = {p_domains_indices{2:end}};
                for cur_p_val = cur_p_domain
                    p_index_new = [p_index cur_p_val];
                    fill_rho(p_domains_rest, p_index_new, traj, is_pos);
                end
            end
        else
            test_run = run_test(traj, p_index);
            if ( test_run > 0 )
                if is_pos
                    set_elem(p_index, 1);
                else
                    set_elem(p_index, -1);
                end
            end
        end
    end

    function fill_rho_naive(p_domains_indices, p_index, traj, is_pos)
        
        if ( numel(p_domains_indices) > 0 )
            cur_p_domain = p_domains_indices{1};
            p_domains_rest = {p_domains_indices{2:end}};
            for cur_p_val = cur_p_domain
                p_index_new = [p_index cur_p_val];
                fill_rho_naive(p_domains_rest, p_index_new, traj, is_pos);
            end
        else
            if ( get_elem(p_index) == 0 )
                test_run = run_test(traj, p_index);
                if ( test_run > 0 )
                    if is_pos
                        set_elem(p_index, 1);
                    else
                        set_elem(p_index, -1);
                    end
                end
            end
        end
    end


    % assumes that p_rho has been filled
    p_corners = [];
    function find_corners( p_domains_indices, p_index )
        if ( numel(p_domains_indices) > 0 )
            cur_p_domain = p_domains_indices{1};
            p_domains_rest = {p_domains_indices{2:end}};
            for cur_p_val = cur_p_domain
                p_index_new = [p_index cur_p_val];
                find_corners(p_domains_rest, p_index_new);
            end
        else
            if ( get_elem(p_index) == 1 )
                is_corner = 1;
                for dim = p_num_dims - k_mono + 1:p_num_dims
                    p_index_new = p_index;
                    if ( p_index(dim) < p_dim_sizes(dim) )
                        p_index_new(dim)=p_index(dim)+1;
                        if ( get_elem(p_index_new) ~= -1 )
                            is_corner = 0;
                            break;
                        end
                    end
                end
                if is_corner
                    p_domain_val = [];
                    for p_dim_num = 1:p_num_dims
                        p_domain_val = [p_domain_val ...
                            p_domains{p_dim_num}(p_index(p_dim_num))];
                    end
                    p_corners = [p_corners p_domain_val'];
                end
            end
        end
    end


num_sims = 0;
tic
for traj = traj_neg
    if ( ~any(traj.X(1,:)) )
        disp('empty traj')
    else
        disp('Called fill_rho neg')
        fill_rho(p_domains_indices, [], traj, 0);
    end
    toc
end

for traj = traj_pos
    if ( ~any(traj.X(1,:)) )
        disp('empty traj')
    else
        disp('Called fill_rho pos')
        fill_rho(p_domains_indices, [], traj, 1);
    end
    toc
end

find_corners(p_domains_indices, []);

end



%
% % calculate array of indices corresponding to all non-mono params
% p_all_non_mono = [];
% if (p_num_dims > k_mono)
%     p_grid = cell(1, p_num_dims - k_mono);
%     [p_grid{:}] = ndgrid(p_domain_indices{1:p_num_dims - k_mono});
%
%     for ii = 1:p_num_dims - k_mono
%         p_all_non_mono = [ p_all_non_mono p_grid{ii}(:)];
%     end
% end
%
% % calculate array of indices corresponding to all but last 2 mono params
% p_all_mono_but2 = [];
% if ( k_mono > 2)
%     p_grid = cell(1, k_mono - 2);
%     [p_grid{:}] = ndgrid(p_domain_indices{p_num_dims - k_mono + 1:...
%         p_num_dims - 2});
%
%     for ii = 1:k_mono - 2
%         p_all_mono_but2 = [ p_all_mono_but2 p_grid{ii}(:)];
%     end
% end
%
%
% switch(k_mono)
%     case 0
%         for traj = traj_neg
%             for row = 1:size(p_all_non_mono, 1)
%                 p_index = p_all_non_mono(row, :);
%                 rho = get_elem(p_index);
%                 if ( rho < 0 )
%                     continue
%                 else
%                     test_res = run_test(traj, p_index);
%                     if ( test_res > 0)
%                         set_elem(p_index, -1);
%                     end
%                 end
%             end
%         end
%
%         for traj = traj_pos
%             for row = 1:size(p_all_non_mono, 1)
%                 p_index = p_all_non_mono(row, :);
%                 rho = get_elem(p_index);
%                 if ( rho > 0 || rho < 0 )
%                     continue
%                 else
%                     test_res = run_test(traj, p_index);
%                     if ( test_res > 0)
%                         set_elem(p_index, 1);
%                     end
%                 end
%             end
%         end
%
%     case 1
%         disp('')
%
% end
%

